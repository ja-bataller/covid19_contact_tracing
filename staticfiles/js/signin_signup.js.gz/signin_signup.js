const toggleForm = () => {
    const container = document.querySelector('.customContainer');
    container.classList.toggle('active');
  };